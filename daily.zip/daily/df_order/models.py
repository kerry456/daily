from django.db import models

# Create your models here.

#订单模型
class OrderInfo(models.Model):
    #订单号
    oid = models.CharField(max_length=20,primary_key=True)
    user = models.ForeignKey('df_user.Userinfo')
    odate = models.DateTimeField(auto_now=True)
    oIsPay = models.IntegerField(default=0)
    otatol = models.DecimalField(max_digits=6,decimal_places=2)
    oaddress = models.CharField(max_length=150,default='')
    zhifu = models.IntegerField(default=0)

#订单详情页
class OrderDetailInfo(models.Model):
    goods = models.ForeignKey('df_goods.GoodsInfo')
    order = models.ForeignKey(OrderInfo)
    price = models.DecimalField(max_digits=5,decimal_places=2)
    count = models.IntegerField()














