from django.apps import AppConfig

class DfCartConfig(AppConfig):
    name = 'df_order'
